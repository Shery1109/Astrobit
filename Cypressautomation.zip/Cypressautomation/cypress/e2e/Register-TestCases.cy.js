import 'cypress-xpath';

describe('Astrobit', () => {
  it('Open website', () => {
    cy.visit('http://astrobit.ai/')
    cy.url().should('include', 'http://astrobit.ai/');  
  })

  it('TC01- Verify User should be registered with all valid inputs', () => {
    cy.visit('http://astrobit.ai/')
    cy.xpath('//*[@id="root"]/header/nav/div/a[1]/button').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[1]/input').type('TestUser')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[2]/input').type('test164@gmail.com')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[3]/input').type('123456')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[4]/input').type('123456')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[5]/input').type('Test address')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/button').click()
    cy.wait(5000)
    cy.get('div.Toastify__toast.Toastify__toast--success').should('be.visible').and('contain','User registered successfully!')
  })

  it('TC02- Verify that when user register with already register email show error', () => {
    cy.visit('http://astrobit.ai/')
    cy.xpath('//*[@id="root"]/header/nav/div/a[1]/button').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[1]/input').type('TestUser')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[2]/input').type('test151@gmail.com')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[3]/input').type('123456')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[4]/input').type('123456')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[5]/input').type('Test address')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/button').click()
    cy.wait(5000)
    cy.get('.Toastify__toast.Toastify__toast--error').should('be.visible').and('contain','Email Already Exist')
  })


  it('TC03- Verify that when user register the password lenght should be more than or equal to six characters', () => {
    cy.visit('http://astrobit.ai/')
    cy.xpath('//*[@id="root"]/header/nav/div/a[1]/button').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[1]/input').type('TestUser')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[2]/input').type('test151@gmail.com')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[3]/input').type('123')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[4]/input').type('123')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[5]/input').type('Test address')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/button').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[3]/p').should('be.visible').and('contain','Password must be at least 6 characters long')
  })  

  it('TC04- Verify that when user register the confirm password field should match with password field', () => {
    cy.visit('http://astrobit.ai/')
    cy.xpath('//*[@id="root"]/header/nav/div/a[1]/button').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[1]/input').type('TestUser')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[2]/input').type('test151@gmail.com')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[3]/input').type('123456')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[4]/input').type('12345678')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[5]/input').type('Test address')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/button').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[4]/p').should('be.visible').and('contain','Passwords do not match')
  })

  it('TC05- Verify that when user register without enter username show error', () => {
    cy.visit('http://astrobit.ai/')
    cy.xpath('//*[@id="root"]/header/nav/div/a[1]/button').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[2]/input').type('test151@gmail.com')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[3]/input').type('123456')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[4]/input').type('123456')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[5]/input').type('Test address')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/button').click()
    cy.wait(5000)
    cy.get('div.Toastify__toast.Toastify__toast--error').should('be.visible').and('contain','Request failed with status code 400')
  })

})