import 'cypress-xpath';

describe('Astrobit', () => {
  it('Open website', () => {
    cy.visit('http://astrobit.ai/')
    cy.url().should('include', 'http://astrobit.ai/');  
  })

  it('TC01-Verify Login with valid email and valid passsword', () => {
    cy.visit('http://astrobit.ai/')
    cy.xpath('//*[@id="root"]/header/nav/div/a[2]/button').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[1]/input').type('test151@gmail.com')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[2]/input').type('123456')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[3]/label/input').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/button').click()
    cy.wait(5000)
    cy.get('div.Toastify__toast.Toastify__toast--success').should('be.visible').and('contain','Login successful!')
  })

  it('TC02- Verify login with invalid email and valid password', () => {
    cy.visit('http://astrobit.ai/')
    cy.xpath('//*[@id="root"]/header/nav/div/a[2]/button').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[1]/input').type('tes@gmail.com')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[2]/input').type('123456')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[3]/label/input').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/button').click()
    cy.wait(5000)
    cy.get('div.Toastify__toast.Toastify__toast--error').should('be.visible').and('contain','Request failed with status code 500')
  })

  it('TC03- Verify login with valid Email and invalid password', () => {
    cy.visit('http://astrobit.ai/')
    cy.xpath('//*[@id="root"]/header/nav/div/a[2]/button').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[1]/input').type('test6@gmail.com')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[2]/input').type('1234567')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[3]/label/input').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/button').click()
    cy.wait(5000)
    cy.get('div.Toastify__toast.Toastify__toast--error').should('be.visible').and('contain','Request failed with status code 400')
  })

  it('TC05- Verify login with invalid email and invalid password', () => {
    cy.visit('http://astrobit.ai/')
    cy.xpath('//*[@id="root"]/header/nav/div/a[2]/button').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[1]/input').type('testing100@gmail.com')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[2]/input').type('1234567')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[3]/label/input').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/button').click()
    cy.wait(5000)
    cy.get('div.Toastify__toast.Toastify__toast--error').should('be.visible').and('contain','Request failed with status code 500')
  })

})