import 'cypress-xpath';

describe('Astrobit', () => {
  it('Open website', () => {
    cy.visit('http://astrobit.ai/')
    cy.url().should('include', 'http://astrobit.ai/');  
  })

  it('TC01- Verify that user should subscribed the plan', () => {
    cy.visit('http://astrobit.ai/')
    cy.viewport(1920, 1080);
    cy.xpath('//*[@id="root"]/header/nav/div/a[1]/button').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[1]/input').type('TestUser')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[2]/input').type('test131@gmail.com')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[3]/input').type('123456')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[4]/input').type('123456')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[5]/input').type('Test address')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/button').click()
    cy.wait(5000)
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[1]/input').type('test131@gmail.com')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[2]/input').type('123456')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[3]/label/input').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/button').click()
    cy.xpath('//*[@id="root"]/div/div/aside/div[2]/nav/div[1]/ul/li[6]/a').click()
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div/div[2]/button').click()
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div[2]/div/div/input').click()
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div[2]/div/div/input').attachFile('contract.pdf')
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div[2]/div/div/button').click()
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div[2]/div/div/div[1]/input').type('500')
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div[2]/div/div/div[2]/select').select('Bitcoin')
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div[2]/div/div/button').click()
    cy.wait(5000)
    cy.get('button.bg-gradient-to-r.from-purple-500.to-pink-500').click();
    cy.wait(5000)
    cy.get('div.Toastify__toast.Toastify__toast--success').should('be.visible').and('contain','Deposit Successfull')
  })


  it('TC02- Verify that user should cancel the plan after subscription', () => {
    cy.visit('http://astrobit.ai/')
    cy.viewport(1920, 1080);
    cy.xpath('//*[@id="root"]/header/nav/div/a[2]/button').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[1]/input').type('test125@gmail.com')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[2]/input').type('123456')
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[3]/label/input').click()
    cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/button').click()
    cy.wait(5000)
    cy.xpath('//*[@id="root"]/div/div/aside/div[2]/nav/div[1]/ul/li[6]/a').click()
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div/div[2]/button').click()
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div[2]/div/div/input').click()
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div[2]/div/div/input').attachFile('contract.pdf')
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div[2]/div/div/button').click()
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div[2]/div/div/div[1]/input').type('500')
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div[2]/div/div/div[2]/select').select('Bitcoin')
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div[2]/div/div/button').click()
    cy.get('button.bg-gradient-to-r.from-purple-500.to-pink-500').click();
    cy.wait(5000)
    cy.xpath('//*[@id="root"]/div/div/aside/div[2]/nav/div[1]/ul/li[6]/a').click()
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div/div[2]/button').click()
    cy.xpath('//*[@id="root"]/div/div/div/main/div/div/div[2]/div[2]/div[2]/div/div/button[2]').click()
    cy.wait(3000)
    cy.get('div.Toastify__toast.Toastify__toast--success').should('be.visible').and('contain','Plan cancelled successfully')
  })

})    
