class Login
{

    clickLogin(loginbtn)

    {
        cy.xpath('//*[@id="root"]/header/nav/div/a[2]/button').click()
    }
    setEmail(email)
    {
        cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[1]/input').type(email);
    
    }

    setPassword(password)
    {
        cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/div[2]/input').type(password);
    
    }
    
    clickSubmit(submit)
    {
        cy.xpath('//*[@id="root"]/div/div[2]/div/div/div/form/button').click()
    }

    verifyLogin()
    {
        cy.get('div.Toastify__toast.Toastify__toast--success').should('be.visible').and('contain','Login successful!')
    }

}

export default Login;